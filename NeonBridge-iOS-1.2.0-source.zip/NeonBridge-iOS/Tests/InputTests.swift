import XCTest
@testable import NeonBridge

final class InputTests: XCTestCase {
    func testAddressAndPortAreSeparate() throws {
        XCTAssertThrowsError(try ValidatedEndpoint(host: "http://192.168.3.4", port: "5555"))
        XCTAssertThrowsError(try ValidatedEndpoint(host: "192.168.3.4:5555", port: "5555"))
        XCTAssertThrowsError(try ValidatedEndpoint(host: "tv\nother", port: "5555"))
        for port in ["0", "-1", "65536", "abc", ""] {
            XCTAssertThrowsError(try ValidatedEndpoint(host: "192.168.3.4", port: port))
        }
        XCTAssertEqual(try ValidatedEndpoint(host: " 192.168.3.4 ", port: "5555").host, "192.168.3.4")
        XCTAssertEqual(try ValidatedEndpoint(host: "[fe80::1%en0]", port: "65535").host, "fe80::1%en0")
    }
    func testIPhoneLoopbackCannotBeMistakenForAndroidSelfConnection() {
        for host in ["localhost", "LOCALHOST.", "localhost.localdomain", "127.0.0.1", "127.2.3.4", "::1", "[::1]", "0:0:0:0:0:0:0:1", "::ffff:127.0.0.1"] {
            XCTAssertThrowsError(try ValidatedEndpoint(host: host, port: "5555")) { error in
                XCTAssertTrue(error.localizedDescription.contains("iPhone"))
            }
        }
    }
    func testSavedDeviceRoundTripContainsNoAuthorizationToken() throws {
        let device = SavedDevice(name: "TV", host: "192.168.3.4", port: 8002, kind: .samsung)
        let data = try JSONEncoder().encode(device)
        XCTAssertEqual(try JSONDecoder().decode(SavedDevice.self, from: data), device)
        XCTAssertFalse(String(decoding: data, as: UTF8.self).lowercased().contains("token"))
    }
    func testRefusedConnectionGuidanceDoesNotClaimToEnableADB() {
        let text = bridgeError(NSError(domain: NSPOSIXErrorDomain, code: 61))
        XCTAssertTrue(text.contains("отклонено"))
        XCTAssertTrue(text.contains("не может включить"))
    }
    func testCancelledOperationHasReadableMessage() {
        XCTAssertEqual(bridgeError(CancellationError()), "Операция отменена.")
    }
}
