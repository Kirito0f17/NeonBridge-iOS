import SwiftUI
import UIKit
import ADBCore
import UniformTypeIdentifiers

struct FilesView: View {
    @EnvironmentObject var model: BridgeModel
    @State private var importing = false
    @State private var selectedUpload: URL?
    @State private var folderPrompt = false
    @State private var folderName = ""
    var body: some View {
        Screen(title: "ФАЙЛЫ") {
            ActiveDeviceBar()
            HStack {
                TextField("Абсолютный путь", text: $model.path).textInputAutocapitalization(.never).autocorrectionDisabled().font(.system(.callout, design: .monospaced))
                Button { model.loadFiles() } label: { Image(systemName: "arrow.right") }.accessibilityLabel("Открыть каталог")
            }.padding(14).background(Color.bridgePanel, in: RoundedRectangle(cornerRadius: 12))
            HStack {
                Button("Выше") {
                    model.path = (model.path as NSString).deletingLastPathComponent
                    if model.path.isEmpty { model.path = "/" }; model.loadFiles()
                }
                Button("Обновить") { model.loadFiles() }
                Spacer()
                Button { folderName = ""; folderPrompt = true } label: { Image(systemName: "folder.badge.plus") }.accessibilityLabel("Создать папку")
                Button { importing = true } label: { Image(systemName: "square.and.arrow.up") }.accessibilityLabel("Передать файл")
            }.buttonStyle(.bordered)
            if !model.connected || !model.android {
                Panel { Text("Для файлов подключите Android по ADB."); Text("В этой iOS-версии SDB предоставляет только терминал. Пульт Samsung не открывает доступ к файлам.").font(.caption).foregroundStyle(.secondary) }
            }
            ForEach(model.files) { entry in
                Panel {
                    HStack {
                        Image(systemName: entry.isDirectory ? "folder.fill" : entry.isSymlink ? "link" : "doc").foregroundStyle(Color.bridgeCyan)
                        VStack(alignment: .leading) {
                            Text(entry.name).lineLimit(2)
                            Text(entry.isDirectory ? "Каталог" : ByteCountFormatter.string(fromByteCount: Int64(clamping: entry.size), countStyle: .file)).font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        if entry.isDirectory {
                            Button { model.path = entry.fullPath; model.loadFiles() } label: { Image(systemName: "chevron.right") }
                        } else if entry.isSymlink {
                            Menu {
                                Button("Открыть как каталог") { model.path = entry.fullPath; model.loadFiles() }
                                Button("Скачать") { model.download(entry) }
                            } label: { Image(systemName: "ellipsis.circle") }
                        } else { Button { model.download(entry) } label: { Image(systemName: "square.and.arrow.down") } }
                    }
                }
            }
            if model.connected && model.files.isEmpty { Text("Откройте каталог кнопкой → или «Обновить». Пустой список также возможен для пустого каталога.").font(.caption).foregroundStyle(.secondary) }
        }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.data, .item]) { result in
            switch result { case .success(let url): selectedUpload = url; case .failure(let error): model.report("Выбор файла", bridgeError(error)) }
        }
        .alert("Передать файл?", isPresented: Binding(get: { selectedUpload != nil }, set: { if !$0 { selectedUpload = nil } })) {
            Button("Передать") { if let url = selectedUpload { model.upload(url, install: false) }; selectedUpload = nil }
            Button("Отмена", role: .cancel) { selectedUpload = nil }
        } message: { Text("\(selectedUpload?.lastPathComponent ?? "") → \(model.path) на выбранном Android. Существующий файл с таким именем будет перезаписан.") }
        .alert("Новая папка", isPresented: $folderPrompt) {
            TextField("Имя папки", text: $folderName)
            Button("Создать") { model.makeFolder(folderName) }
            Button("Отмена", role: .cancel) { }
        }
    }
}
struct AppsView: View {
    @EnvironmentObject var model: BridgeModel
    @State private var system = false
    @State private var search = ""
    @State private var importing = false
    @State private var apk: URL?
    @State private var pendingPackage: String?
    var body: some View {
        Screen(title: "ПРИЛОЖЕНИЯ ANDROID") {
            ActiveDeviceBar()
            Toggle("Включить системные пакеты", isOn: $system)
            HStack {
                Button("Обновить список") { model.loadApps(system: system) }
                Spacer()
                Button("Установить APK") { importing = true }
            }.buttonStyle(.bordered)
            TextField("Поиск по имени пакета", text: $search).textInputAutocapitalization(.never).autocorrectionDisabled().textFieldStyle(.roundedBorder)
            Text("APK устанавливается на подключённый Android, а не на iPhone.").font(.caption).foregroundStyle(.secondary)
            ForEach(model.packages.filter { search.isEmpty || $0.localizedCaseInsensitiveContains(search) }, id: \.self) { package in
                Panel {
                    HStack {
                        Image(systemName: "square.grid.2x2").foregroundStyle(Color.bridgeCyan)
                        Text(package).font(.system(.callout, design: .monospaced)).textSelection(.enabled)
                        Spacer()
                        Menu {
                            Button("Запустить") { model.launchPackage(package) }
                            Button("Сведения") { model.packageAction(package, command: "dumpsys package") }
                            Button("Остановить") { model.packageAction(package, command: "am force-stop") }
                            Button("Удалить у пользователя 0", role: .destructive) { pendingPackage = package }
                        } label: { Image(systemName: "ellipsis.circle").font(.title2) }
                    }
                }
            }
        }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.data, .item]) { result in
            switch result { case .success(let url): apk = url; case .failure(let error): model.report("Выбор APK", bridgeError(error)) }
        }
        .alert("Установить APK на Android?", isPresented: Binding(get: { apk != nil }, set: { if !$0 { apk = nil } })) {
            Button("Установить") { if let apk { model.upload(apk, install: true) }; apk = nil }
            Button("Отмена", role: .cancel) { apk = nil }
        } message: { Text("\(apk?.lastPathComponent ?? ""). Выбирайте APK из доверенного источника. Android может запретить установку.") }
        .alert("Удалить приложение?", isPresented: Binding(get: { pendingPackage != nil }, set: { if !$0 { pendingPackage = nil } })) {
            Button("Удалить", role: .destructive) { if let p = pendingPackage { model.packageAction(p, command: "pm uninstall --user 0") }; pendingPackage = nil }
            Button("Отмена", role: .cancel) { pendingPackage = nil }
        } message: { Text("\(pendingPackage ?? "")\nУдаление системного пакета может нарушить работу Android.") }
    }
}
struct ShellView: View {
    @EnvironmentObject var model: BridgeModel
    @AppStorage("terminalFontSize") private var fontSize = 12.0
    @State private var clearing = false
    var body: some View {
        VStack(spacing: 12) {
            ActiveDeviceBar().padding(.horizontal)
            ScrollViewReader { reader in
                ScrollView {
                    Text(model.terminal).font(.system(size: fontSize, design: .monospaced)).foregroundStyle(Color.bridgeCyan)
                        .textSelection(.enabled).frame(maxWidth: .infinity, alignment: .leading).padding()
                    Color.clear.frame(height: 1).id("end")
                }.onChange(of: model.terminal) { _, _ in reader.scrollTo("end", anchor: .bottom) }
            }
            Text("Команды выполняются отдельно: cd не сохраняется между запусками.").font(.caption2).foregroundStyle(.secondary).padding(.horizontal)
            HStack {
                TextField("Команда…", text: $model.shellCommand).font(.system(.callout, design: .monospaced)).textInputAutocapitalization(.never).autocorrectionDisabled().submitLabel(.send).onSubmit { model.runShell() }
                Button { model.runShell() } label: { Image(systemName: "arrow.right.circle.fill").font(.title) }.accessibilityLabel("Выполнить команду")
            }.padding().background(Color.bridgePanel)
        }.background { GridBackdrop() }.navigationTitle("SHELL").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                Button { model.exportTerminal() } label: { Image(systemName: "square.and.arrow.up") }.accessibilityLabel("Экспортировать вывод")
                Button { clearing = true } label: { Image(systemName: "trash") }.accessibilityLabel("Очистить вывод")
            }
            .alert("Очистить вывод терминала?", isPresented: $clearing) {
                Button("Очистить", role: .destructive) { model.clearTerminal() }
                Button("Отмена", role: .cancel) { }
            }
    }
}
struct RemoteView: View {
    @EnvironmentObject var model: BridgeModel
    @State private var power = false
    var body: some View {
        Screen(title: "ПУЛЬТ") {
            ActiveDeviceBar()
            VStack(spacing: 12) {
                key("↑", "KEY_UP", 19)
                HStack(spacing: 12) { key("←", "KEY_LEFT", 21); key("OK", "KEY_ENTER", 23); key("→", "KEY_RIGHT", 22) }
                key("↓", "KEY_DOWN", 20)
            }.frame(maxWidth: .infinity).padding(.vertical, 20)
            HStack { key("Назад", "KEY_RETURN", 4); key("Домой", "KEY_HOME", 3); key("Меню", "KEY_MENU", 82) }
            HStack { key("VOL −", "KEY_VOLDOWN", 25); key("Mute", "KEY_MUTE", 164); key("VOL +", "KEY_VOLUP", 24) }
            HStack { key("⏪", "KEY_REWIND", 89); key("▶/Ⅱ", "KEY_PLAY", 85); key("⏩", "KEY_FF", 90) }
            Button("Питание / сон", role: .destructive) { power = true }.buttonStyle(.bordered)
        }.alert("Отправить команду питания?", isPresented: $power) {
            Button("Отправить", role: .destructive) { model.remoteKey(samsung: "KEY_POWER", android: 26) }
            Button("Отмена", role: .cancel) { }
        }
    }
    private func key(_ title: String, _ samsung: String, _ android: Int) -> some View {
        Button(title) { model.remoteKey(samsung: samsung, android: android) }
            .font(.system(.headline, design: .monospaced)).frame(minWidth: 64, maxWidth: .infinity, minHeight: 54)
            .background(Color.bridgePanel, in: RoundedRectangle(cornerRadius: 14)).overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.bridgeCyan.opacity(0.3)))
    }
}
struct SettingsView: View {
    @EnvironmentObject var model: BridgeModel
    @AppStorage("terminalFontSize") private var fontSize = 12.0
    @State private var resetting = false
    var body: some View {
        Screen(title: "НАСТРОЙКИ") {
            Panel {
                Text("NEONBRIDGE / iOS 1.0.1").font(.system(.headline, design: .monospaced)).foregroundStyle(Color.bridgeCyan)
                Text("Android · Wireless ADB · Samsung Remote · SDB Shell").font(.caption).foregroundStyle(.secondary)
            }
            SectionLabel(title: "ТЕРМИНАЛ")
            Panel { Text("Размер шрифта: \(Int(fontSize))"); Slider(value: $fontSize, in: 10...20, step: 1) }
            SectionLabel(title: "СЕТЬ")
            Button("Открыть настройки iPhone") { if let url = URL(string: UIApplication.openSettingsURLString) { UIApplication.shared.open(url) } }.buttonStyle(.bordered)
            Text("Разрешите NeonBridge доступ к локальной сети. iPhone и целевое устройство должны быть в одной домашней сети. При уходе приложения в фон iOS может приостановить сеть; переподключитесь вручную.").font(.caption).foregroundStyle(.secondary)
            SectionLabel(title: "ПОМОЩЬ")
            NavigationLink("Как подключиться") { HelpView() }
            NavigationLink("Лицензия ADBCore") { LicenseView() }
            Text("Legacy ADB и SDB не шифруют трафик. TLS ADB и пульт используют самоподписанные сертификаты без закрепления серверного сертификата. Проверяйте адрес и подтверждайте подключение только на своём устройстве.").font(.caption).foregroundStyle(.secondary)
            SectionLabel(title: "ДАННЫЕ")
            Button("Экспортировать терминал") { model.exportTerminal() }.buttonStyle(.bordered)
            Button("Удалить локальные данные", role: .destructive) { resetting = true }.buttonStyle(.bordered)
            Text("Адреса находятся в данных приложения, ключи ADB и токены Samsung — в Keychain. Аккаунта NeonBridge, аналитики и сервера-посредника нет. Удаление приложения может оставить записи Keychain; для сброса ключей используйте эту кнопку.").font(.caption).foregroundStyle(.secondary)
        }.alert("Удалить устройства, ключи и вывод?", isPresented: $resetting) {
            Button("Удалить", role: .destructive) { model.reset() }
            Button("Отмена", role: .cancel) { }
        } message: { Text("Соединение закроется. На Android и телевизорах данные не меняются. Экспортированные вами файлы остаются в выбранном месте.") }
    }
}
struct HelpView: View {
    var body: some View {
        Screen(title: "КАК ПОДКЛЮЧИТЬСЯ") {
            Text("Сначала выберите правильный тип устройства. Отладка включается на целевом Android или ТВ, а разрешение локальной сети — на iPhone.").foregroundStyle(.secondary)
            ForEach(ConnectionGuide.all) { guide in
                Panel {
                    Text(guide.title).font(.headline).foregroundStyle(Color.bridgeCyan)
                    ForEach(Array(guide.steps.enumerated()), id: \.offset) { item in
                        Text("\(item.offset + 1). \(item.element)").textSelection(.enabled)
                    }
                    Text(guide.note).font(.caption).foregroundStyle(.secondary).textSelection(.enabled)
                }
            }
        }
    }
}
struct LicenseView: View {
    private var license: String {
        guard let url = Bundle.main.url(forResource: "ADBCore-LICENSE", withExtension: "txt"),
              let text = try? String(contentsOf: url, encoding: .utf8) else { return "ADBCore: MIT License, Copyright (c) 2026 h33h. См. архив проекта." }
        return text
    }
    var body: some View {
        ScrollView { Text(license).font(.system(.caption, design: .monospaced)).textSelection(.enabled).padding() }
            .navigationTitle("ADBCore · MIT")
    }
}
struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController { UIActivityViewController(activityItems: items, applicationActivities: nil) }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) { }
}
