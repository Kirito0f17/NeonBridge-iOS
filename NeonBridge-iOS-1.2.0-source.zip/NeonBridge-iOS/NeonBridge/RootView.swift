import SwiftUI
import UniformTypeIdentifiers

struct RootView: View {
    @EnvironmentObject var model: BridgeModel
    @Environment(\.scenePhase) private var scenePhase
    var body: some View {
        ZStack {
            TabView {
                NavigationStack { DevicesView() }.tabItem { Label("Устройства", systemImage: "iphone") }
                NavigationStack { FilesView() }.tabItem { Label("Файлы", systemImage: "folder") }
                NavigationStack { AppsView() }.tabItem { Label("Приложения", systemImage: "square.grid.2x2") }
                NavigationStack { ShellView() }.tabItem { Label("Shell", systemImage: "terminal") }
                NavigationStack { SettingsView() }.tabItem { Label("Настройки", systemImage: "gearshape") }
            }.tint(.bridgeCyan)
            if let title = model.busy {
                Color.black.opacity(0.65).ignoresSafeArea()
                VStack(spacing: 20) {
                    ProgressView().tint(.bridgeCyan)
                    Text(title).multilineTextAlignment(.center)
                    Button("Отмена и отключение") { model.cancelOperation() }.buttonStyle(.bordered)
                }.padding(28).background(Color.bridgePanel, in: RoundedRectangle(cornerRadius: 20)).padding(24)
            }
        }
        .alert(item: $model.message) { message in
            Alert(title: Text(message.title), message: Text(message.text), dismissButton: .default(Text("Понятно")))
        }
        .sheet(item: $model.sharedFile) { item in ShareSheet(items: [item.url]) }
        .onChange(of: scenePhase) { _, phase in
            if phase == .active { model.refreshConnectionStatus() }
            if phase == .background { model.stopDiscovery() }
        }
    }
}
struct DevicesView: View {
    @EnvironmentObject var model: BridgeModel
    @State private var adding = false
    @State private var inspecting: SavedDevice?
    @State private var forgetting: SavedDevice?
    var body: some View {
        Screen(title: "NEONBRIDGE") {
            Text("Android и телевизоры. Прямое подключение.").foregroundStyle(.secondary)
            Panel {
                Text("ЛОКАЛЬНАЯ СЕТЬ / iOS").font(.system(.caption, design: .monospaced)).foregroundStyle(Color.bridgeCyan)
                Text("Разрешите доступ к локальной сети в настройках iPhone. Ключи и токены хранятся на вашем устройстве.").font(.callout).foregroundStyle(.secondary)
            }
            NavigationLink { DeviceCatalogView() } label: { Label("Модели и форматы приложений", systemImage: "tv") }.buttonStyle(.bordered)
            NavigationLink { HelpView() } label: { Label("Пошаговая инструкция подключения", systemImage: "questionmark.circle") }.buttonStyle(.bordered)
            SectionLabel(title: "СОХРАНЁННЫЕ УСТРОЙСТВА")
            if model.devices.isEmpty {
                Panel {
                    Image(systemName: "iphone.radiowaves.left.and.right").font(.largeTitle).foregroundStyle(Color.bridgeCyan)
                    Text("Ваше первое подключение").font(.title2)
                    Text("Включите отладку на Android или разрешите пульт на телевизоре Samsung.").foregroundStyle(.secondary)
                    Button("＋ Добавить устройство") { adding = true }.buttonStyle(.borderedProminent).tint(.bridgeCyan).foregroundStyle(.black)
                }
            }
            ForEach(model.devices) { device in
                Panel {
                    HStack {
                        Image(systemName: device.kind.symbol).font(.title2).foregroundStyle(Color.bridgeCyan)
                        VStack(alignment: .leading) {
                            Text(device.name).font(.headline)
                            Text("\(device.host):\(device.port)").font(.system(.caption, design: .monospaced)).foregroundStyle(Color.bridgeCyan)
                            Text(device.kind.title).font(.caption).foregroundStyle(.secondary)
                        }
                        Spacer()
                        if model.isDeviceConnected(device.id) { Image(systemName: "circle.fill").foregroundStyle(.green).font(.caption) }
                        Menu {
                            Button("Подключить") { model.connect(device) }
                            Button("Инструменты") { model.selectedID = device.id; inspecting = device }
                            Button("Проверить TCP-порт") { model.probe(device) }
                            Button("Проверить активное подключение") { model.selectedID = device.id; model.verifyConnection() }.disabled(!model.isDeviceConnected(device.id))
                            Button("Отключить") { model.perform("Отключение…") { await model.disconnect() } }.disabled(model.connectedID != device.id)
                            Button("Забыть устройство", role: .destructive) { forgetting = device }
                        } label: { Image(systemName: "ellipsis.circle").font(.title2).padding(6) }
                    }
                }
            }
            SectionLabel(title: "БЕСПРОВОДНОЙ ADB ПОБЛИЗОСТИ")
            Button(model.scanning ? "Остановить поиск" : "Найти Android 11+ в сети") { model.toggleDiscovery() }.buttonStyle(.bordered)
            ForEach(model.nearby) { nearby in
                Panel {
                    Text(nearby.name).font(.headline)
                    Text("\(nearby.host):\(nearby.port)").font(.system(.caption, design: .monospaced))
                    Button("Сохранить адрес подключения") {
                        do {
                            let endpoint = try ValidatedEndpoint(host: nearby.host, port: String(nearby.port))
                            _ = try model.save(name: nearby.name, endpoint: endpoint, kind: .wireless)
                        } catch { model.report("Адрес", bridgeError(error)) }
                    }
                    if let port = nearby.pairingPort { Text("Обнаружен порт сопряжения: \(port)").font(.caption).foregroundStyle(.secondary) }
                }
            }
            Text("Поиск использует Bonjour для беспроводного ADB. Остальные устройства добавляются вручную. Обнаружение не означает разрешение подключения.").font(.caption).foregroundStyle(.secondary)
        }
        .toolbar { Button { adding = true } label: { Image(systemName: "plus") }.accessibilityLabel("Добавить устройство") }
        .sheet(isPresented: $adding) { AddDeviceView() }
        .navigationDestination(item: $inspecting) { device in DeviceToolsView(device: device) }
        .alert("Забыть устройство?", isPresented: Binding(get: { forgetting != nil }, set: { if !$0 { forgetting = nil } })) {
            Button("Удалить", role: .destructive) { if let device = forgetting { model.forget(device) }; forgetting = nil }
            Button("Отмена", role: .cancel) { forgetting = nil }
        } message: { Text("Адрес и токен пульта будут удалены с iPhone.") }
    }
}
struct AddDeviceView: View {
    @EnvironmentObject var model: BridgeModel
    @Environment(\.dismiss) private var dismiss
    @State private var pairing = false
    @State private var kind: DeviceKind = .adb
    @State private var name = ""
    @State private var host = ""
    @State private var port = "5555"
    @State private var pairingPort = ""
    @State private var code = ""
    @State private var validation = ""
    var body: some View {
        NavigationStack {
            Form {
                Section {
                    Picker("Действие", selection: $pairing) { Text("Подключение").tag(false); Text("Сопряжение 11+").tag(true) }.pickerStyle(.segmented)
                    TextField("IP или имя в сети", text: $host).textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.asciiCapable)
                }
                if pairing {
                    Section("На Android откройте окно сопряжения по коду") {
                        TextField("Порт сопряжения", text: $pairingPort).keyboardType(.numberPad)
                        TextField("Код из 6 цифр", text: $code).keyboardType(.numberPad)
                        Text("Оставьте окно с кодом открытым. После сопряжения понадобится другой порт — с главного экрана «Беспроводная отладка».").font(.caption)
                        Button("Сопрячь с Android") { submit() }
                    }
                } else {
                    Section {
                        Picker("Тип устройства", selection: $kind) { ForEach(DeviceKind.allCases) { Text($0.title).tag($0) } }
                            .onChange(of: kind) { _, value in port = value.defaultPort }
                        TextField("Название (необязательно)", text: $name)
                        TextField("Порт подключения", text: $port).keyboardType(.numberPad).disabled(kind == .samsung)
                        Text(hint).font(.caption).foregroundStyle(.secondary)
                    }
                    Section { Button("Сохранить и подключить") { submit() } }
                }
                if !validation.isEmpty { Section { Text(validation).foregroundStyle(.red) } }
            }.navigationTitle(pairing ? "Сопряжение Android" : "Добавить устройство")
                .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Закрыть") { dismiss() } } }
        }.tint(.bridgeCyan)
    }
    private var hint: String {
        switch kind {
        case .adb: return "На устройстве должен быть включён ADB по TCP. На старых Android его часто сначала включают через USB с компьютера: adb tcpip 5555. Сам режим разработчика сетевую отладку не включает."
        case .wireless: return "Сначала выполните сопряжение по шестизначному коду. Здесь укажите порт подключения с главного экрана беспроводной отладки, а не порт сопряжения."
        case .samsung: return "Samsung Remote использует TLS WebSocket 8002. Подтвердите запрос на ТВ. Самоподписанный сертификат принимается только для выбранного адреса; закрепление сертификата не реализовано."
        case .sdb: return "SDB — режим разработки Tizen, обычно порт 26101. Разрешите IP iPhone в Developer Mode ТВ. Здесь доступен только терминал; прошивка Samsung может запрещать shell."
        }
    }
    private func submit() {
        do {
            let endpoint = try ValidatedEndpoint(host: host, port: pairing ? pairingPort : port)
            if pairing {
                guard code.count == 6, code.utf8.allSatisfy({ $0 >= 48 && $0 <= 57 }) else { throw BridgeFailure("Введите код из шести цифр") }
                dismiss(); model.pair(endpoint, code: code)
            } else {
                let device = try model.save(name: name, endpoint: endpoint, kind: kind)
                dismiss(); model.connect(device)
            }
        } catch { validation = bridgeError(error) }
    }
}
struct DeviceToolsView: View {
    @EnvironmentObject var model: BridgeModel
    @Environment(\.dismiss) private var dismiss
    let device: SavedDevice
    var body: some View {
        Screen(title: device.name) {
            ActiveDeviceBar()
            if !model.connected { Button("Подключить") { dismiss(); model.connect(device) }.buttonStyle(.borderedProminent) }
            Text(device.kind.title).foregroundStyle(.secondary)
            if device.kind == .sdb {
                Text("На вкладке Shell доступны команды SDB. На обычных телевизорах Samsung служба shell может быть заблокирована производителем.")
            } else {
                NavigationLink { RemoteView() } label: { Label("Пульт", systemImage: "dpad") }.buttonStyle(.bordered)
                if device.kind != .samsung { Button { model.screenshot() } label: { Label("Сохранить снимок экрана", systemImage: "camera") }.buttonStyle(.bordered) }
            }
            Button("Проверить TCP-порт") { model.probe(device) }.buttonStyle(.bordered)
            Button("Проверить активное подключение") { model.verifyConnection() }.buttonStyle(.bordered).disabled(!model.connected)
            Button("Отключить", role: .destructive) { model.perform("Отключение…") { await model.disconnect() } }.disabled(model.connectedID != device.id)
        }.toolbar { Button("Закрыть") { dismiss() } }
    }
}
