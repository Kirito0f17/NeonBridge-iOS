import Foundation
import Network

private final class ProbeGate: @unchecked Sendable {
    let lock = NSLock()
    var completed = false
    func claim() -> Bool { lock.lock(); defer { lock.unlock() }; if completed { return false }; completed = true; return true }
}
enum PortProbe {
    static func check(_ endpoint: ValidatedEndpoint) async throws {
        let connection = NWConnection(host: NWEndpoint.Host(endpoint.host), port: NWEndpoint.Port(rawValue: endpoint.port)!, using: .tcp)
        let gate = ProbeGate()
        _ = try await withTaskCancellationHandler(operation: {
            try Task.checkCancellation()
            try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Bool, Error>) in
                let finish: @Sendable (Result<Bool, Error>) -> Void = { result in
                    guard gate.claim() else { return }
                    connection.cancel(); continuation.resume(with: result)
                }
                connection.stateUpdateHandler = { state in
                    switch state {
                    case .ready: finish(.success(true))
                    case .failed(let error): finish(.failure(error))
                    case .cancelled: finish(.failure(CancellationError()))
                    default: break
                    }
                }
                connection.start(queue: .global(qos: .userInitiated))
                DispatchQueue.global().asyncAfter(deadline: .now() + 6) {
                    finish(.failure(BridgeFailure("Время ожидания проверки порта истекло (timeout).")))
                }
            }
        }, onCancel: { connection.cancel() })
    }
}
