import SwiftUI
import ADBCore

struct AppMessage: Identifiable {
    let id = UUID()
    let title: String
    let text: String
}
struct SharedFile: Identifiable {
    let id = UUID()
    let url: URL
}

@MainActor final class BridgeModel: ObservableObject {
    @Published private(set) var devices: [SavedDevice] = []
    @Published var selectedID: UUID? {
        didSet {
            if oldValue != selectedID { files = []; packages = []; path = "/sdcard" }
        }
    }
    @Published private(set) var connectedID: UUID?
    @Published var message: AppMessage?
    @Published var sharedFile: SharedFile?
    @Published private(set) var busy: String?
    @Published var shellCommand = ""
    @Published private(set) var terminal = "// NEONBRIDGE · iOS\n// Подключите своё устройство в домашней сети.\n"
    @Published var path = "/sdcard"
    @Published private(set) var files: [FileEntry] = []
    @Published private(set) var packages: [String] = []
    @Published private(set) var nearby: [DiscoveredDevice] = []
    @Published private(set) var scanning = false
    private var client: ADBClient?
    private var remote: SamsungRemote?
    private var operation: Task<Void, Never>?
    private var ticket: UUID?
    private let discovery = ADBDeviceDiscovery()
    private var discoveryTask: Task<Void, Never>?

    var selected: SavedDevice? { devices.first { $0.id == selectedID } }
    var connected: Bool { selectedID.map(isDeviceConnected) ?? false }
    func isDeviceConnected(_ id: UUID) -> Bool {
        guard connectedID == id, let device = devices.first(where: { $0.id == id }) else { return false }
        return device.kind == .samsung ? remote?.connected == true : client?.isConnected == true
    }
    var android: Bool { selected?.kind == .adb || selected?.kind == .wireless }

    init() {
        do { devices = try DeviceDisk.load() }
        catch { message = AppMessage(title: "Не удалось прочитать список устройств", text: error.localizedDescription + "\nФайл не перезаписан автоматически.") }
    }
    func report(_ title: String, _ text: String) { message = AppMessage(title: title, text: text.count > 30000 ? String(text.prefix(30000)) + "\n… Показаны первые 30 000 символов." : text) }
    func perform(_ title: String, work: @escaping @MainActor () async throws -> Void) {
        guard busy == nil else { return }
        let id = UUID(); ticket = id; busy = title
        operation = Task { [weak self] in
            do { try Task.checkCancellation(); try await work() }
            catch is CancellationError { }
            catch { if !Task.isCancelled { self?.report("Не удалось выполнить", bridgeError(error)) } }
            guard self?.ticket == id else { return }
            self?.busy = nil; self?.operation = nil; self?.ticket = nil
        }
    }
    func cancelOperation() {
        operation?.cancel()
        // Router shutdown unblocks a waiting shell read; pairing honors task cancellation.
        let previous = client; client = nil
        remote?.close(); remote = nil; connectedID = nil
        Task { await previous?.disconnect() }
    }
    func disconnect() async {
        let previous = client; client = nil
        remote?.close(); remote = nil; connectedID = nil
        await previous?.disconnect()
    }
    @discardableResult func save(name: String, endpoint: ValidatedEndpoint, kind: DeviceKind) throws -> SavedDevice {
        let name = name.trimmingCharacters(in: .whitespacesAndNewlines)
        if let index = devices.firstIndex(where: { $0.host == endpoint.host && $0.port == endpoint.port && $0.kind == kind }) {
            var copy = devices; copy[index].name = name.isEmpty ? endpoint.host : String(name.prefix(80))
            try DeviceDisk.save(copy); devices = copy; return copy[index]
        }
        let device = SavedDevice(name: name.isEmpty ? endpoint.host : String(name.prefix(80)), host: endpoint.host, port: endpoint.port, kind: kind)
        let copy = devices + [device]; try DeviceDisk.save(copy); devices = copy; return device
    }
    func forget(_ device: SavedDevice) {
        perform("Удаление устройства…") {
            if self.connectedID == device.id { await self.disconnect() }
            let copy = self.devices.filter { $0.id != device.id }
            try DeviceDisk.save(copy); try PrivateStore.setToken(nil, for: device.id)
            self.devices = copy
            if self.selectedID == device.id { self.selectedID = nil }
        }
    }
    func connect(_ device: SavedDevice) {
        perform(device.kind == .samsung ? "Разрешите подключение на телевизоре…" : "Подключение к \(device.host):\(device.port)…") {
            _ = try ValidatedEndpoint(host: device.host, port: String(device.port))
            guard device.kind != .samsung || device.port == 8002 else { throw BridgeFailure("Пульт Samsung этой версии использует порт 8002. Создайте новое подключение с этим портом.") }
            await self.disconnect(); try Task.checkCancellation(); self.selectedID = device.id
            do {
                if device.kind == .samsung {
                    let remote = SamsungRemote(); self.remote = remote
                    remote.onDisconnect = { [weak self] in self?.connectedID = nil }
                    let token = try await remote.connect(host: device.host, token: PrivateStore.token(device.id))
                    try Task.checkCancellation(); try PrivateStore.setToken(token, for: device.id)
                } else {
                    let client = try ADBClient(); self.client = client
                    try await client.connect(host: device.host, port: device.port,
                                             legacySDB: device.kind == .sdb,
                                             requireTLS: device.kind == .wireless)
                    try Task.checkCancellation()
                }
                self.connectedID = device.id
                self.files = []; self.packages = []; self.path = "/sdcard"
                self.append("\n// Подключено: \(device.name) · \(device.host):\(device.port)\n")
            } catch { await self.disconnect(); throw error }
        }
    }
    func pair(_ endpoint: ValidatedEndpoint, code: String) {
        perform("Сопряжение Android 11+…") {
            let peer = try await ADBPairing.pair(host: endpoint.host, port: endpoint.port, code: code)
            self.report("Сопряжение выполнено", "Ключ сохранён. \(peer.name)\nТеперь подключитесь к порту с главного экрана «Беспроводная отладка». Он отличается от порта сопряжения.")
        }
    }
    func probe(_ device: SavedDevice) {
        perform("Проверка порта…") {
            let endpoint = try ValidatedEndpoint(host: device.host, port: String(device.port))
            try await PortProbe.check(endpoint)
            self.report("TCP-порт доступен", "\(device.host):\(device.port) принимает TCP-соединения. Это не подтверждение протокола ADB и не разрешение отладки. Выберите «Подключить» для авторизации.")
        }
    }
    func refreshConnectionStatus() {
        if let id = connectedID, let device = devices.first(where: { $0.id == id }) {
            let alive = device.kind == .samsung ? remote?.connected == true : client?.isConnected == true
            if !alive { connectedID = nil }
        }
        objectWillChange.send()
    }
    func verifyConnection() {
        perform("Проверка активного подключения…") {
            guard self.connected, let device = self.selected else { throw BridgeFailure("Сначала подключите выбранное устройство. Проверка TCP-порта доступна и без активной сессии.") }
            if device.kind == .samsung {
                guard let remote = self.remote else { throw BridgeFailure("Пульт отключён") }
                try await remote.verify()
                self.report("Пульт отвечает", "Телевизор \(device.name) ответил на WebSocket ping. Сессия была разрешена телевизором. Для проверки управления откройте пульт и нажмите, например, «Домой».")
            } else {
                let response = try await self.command("echo NEONBRIDGE_CONNECTION_OK")
                guard response.components(separatedBy: .newlines).contains("NEONBRIDGE_CONNECTION_OK") else {
                    throw BridgeFailure("Устройство не вернуло ожидаемый ответ shell. Подключение TCP не гарантирует доступ к этой службе. Ответ: " + String(response.prefix(1000)))
                }
                self.report("Отладка отвечает", "Устройство \(device.name) выполнило проверочную команду через \(device.kind == .sdb ? "SDB" : "ADB"). Доступ к shell подтверждён в этот момент. Права на файлы, APK и системные команды проверяются отдельно.")
            }
        }
    }
    private func adb(requireAndroid: Bool = false) throws -> ADBClient {
        guard connected, let client, selected?.kind != .samsung else { throw BridgeFailure("Нет активного ADB/SDB-соединения. Подключите устройство на вкладке «Устройства».") }
        if requireAndroid && !android { throw BridgeFailure("Эта функция требует Android. Пульт Samsung и SDB — отдельные протоколы.") }
        return client
    }
    private func command(_ text: String) async throws -> String {
        let client = try adb()
        if selected?.kind == .sdb {
            let stream = try await client.openStream(destination: "shell:\(text)")
            var output = Data()
            do {
                while true {
                    try Task.checkCancellation()
                    let packet = try await stream.readMessage(timeout: 30)
                    if packet.commandType == .close { await stream.acknowledgeRemoteClose(); break }
                    if packet.commandType == .write {
                        guard output.count + packet.data.count <= 8 * 1024 * 1024 else { throw BridgeFailure("Вывод превышает 8 МБ") }
                        output.append(packet.data); try await stream.sendReady()
                    }
                }
                return String(decoding: output, as: UTF8.self)
            } catch { try? await stream.close(); throw error }
        }
        return try await client.shell(text)
    }
    func runShell() {
        let text = shellCommand.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { return }
        perform("Выполнение команды…") {
            self.shellCommand = ""; self.append("\n$ \(text)\n")
            do { self.append(try await self.command(text) + "\n") }
            catch { self.append("[ошибка] \(bridgeError(error))\n"); throw error }
        }
    }
    func clearTerminal() { terminal = "" }
    private func append(_ value: String) { terminal += value; if terminal.count > 150_000 { terminal = String(terminal.suffix(150_000)) } }
    func exportTerminal() {
        perform("Экспорт терминала…") {
            let url = try self.exportLocation("shell.txt")
            try self.terminal.write(to: url, atomically: true, encoding: .utf8)
            self.sharedFile = SharedFile(url: url)
        }
    }
    func loadFiles() {
        perform("Чтение каталога…") {
            let client = try self.adb(requireAndroid: true)
            guard self.path.hasPrefix("/"), !self.path.contains("\0") else { throw BridgeFailure("Укажите абсолютный путь без нулевых символов") }
            let result = try await client.listDirectoryEntries(self.path)
            self.files = result.sorted { $0.isDirectory == $1.isDirectory ? $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending : $0.isDirectory }
        }
    }
    func makeFolder(_ name: String) {
        perform("Создание каталога…") {
            _ = try self.adb(requireAndroid: true)
            guard !name.isEmpty, !name.contains("/"), !name.contains("\0"), name != ".", name != ".." else { throw BridgeFailure("Некорректное имя папки") }
            let full = self.path + (self.path.hasSuffix("/") ? "" : "/") + name
            let result = try await self.command("mkdir -- " + ADBClient.shellQuote(full))
            self.report("Ответ устройства", result.isEmpty ? "Папка создана. Обновите список." : result)
        }
    }
    func download(_ entry: FileEntry) {
        perform("Скачивание файла…") {
            let client = try self.adb(requireAndroid: true)
            let url = try self.exportLocation(entry.name)
            try await client.pullFile(remotePath: entry.fullPath, to: url)
            self.sharedFile = SharedFile(url: url)
        }
    }
    func upload(_ url: URL, install: Bool) {
        perform(install ? "Передача и установка APK…" : "Передача файла…") {
            let client = try self.adb(requireAndroid: true)
            let access = url.startAccessingSecurityScopedResource()
            defer { if access { url.stopAccessingSecurityScopedResource() } }
            let destination = install ? "/data/local/tmp/neonbridge-\(UUID().uuidString).apk" : self.path + (self.path.hasSuffix("/") ? "" : "/") + url.lastPathComponent
            guard !destination.contains("\0") else { throw BridgeFailure("Некорректное имя файла") }
            do {
                try await client.pushFile(from: url, to: destination)
                if install {
                    let result = try await client.shell("pm install -r " + ADBClient.shellQuote(destination))
                    self.report("Ответ установщика Android", result)
                } else { self.report("Файл передан", destination) }
            } catch {
                if install { _ = try? await client.shell("rm -f -- " + ADBClient.shellQuote(destination)) }
                throw error
            }
            if install { _ = try? await client.shell("rm -f -- " + ADBClient.shellQuote(destination)) }
        }
    }
    func loadApps(system: Bool) {
        perform("Чтение списка пакетов…") { self.packages = try await self.adb(requireAndroid: true).listPackages(includeSystem: system) }
    }
    func launchPackage(_ package: String) {
        perform("Запуск приложения…") {
            let client = try self.adb(requireAndroid: true)
            let response = try await client.shell("monkey -p " + ADBClient.shellQuote(package) + " -c android.intent.category.LAUNCHER 1")
            self.report("Ответ Android", response)
        }
    }
    func packageAction(_ package: String, command: String) {
        perform("Команда приложению…") {
            let client = try self.adb(requireAndroid: true)
            let response = try await client.shell(command + " " + ADBClient.shellQuote(package))
            self.report("Ответ Android", response.isEmpty ? "Команда завершена без вывода" : response)
        }
    }
    func remoteKey(samsung: String, android: Int) {
        perform("Отправка кнопки…") {
            if self.selected?.kind == .samsung {
                guard self.connected, let remote = self.remote else { throw BridgeFailure("Подключите телевизор Samsung") }
                try await remote.key(samsung)
            } else { _ = try await self.adb(requireAndroid: true).shell("input keyevent \(android)") }
        }
    }
    func screenshot() {
        perform("Снимок экрана…") {
            let data = try await self.adb(requireAndroid: true).takeScreenshot()
            guard data.starts(with: [137,80,78,71,13,10,26,10]) else { throw BridgeFailure("Устройство не вернуло PNG") }
            let url = try self.exportLocation("screen.png"); try data.write(to: url, options: .atomic)
            self.sharedFile = SharedFile(url: url)
        }
    }
    private func exportLocation(_ name: String) throws -> URL {
        let directory = FileManager.default.temporaryDirectory.appendingPathComponent("neonbridge-exports").appendingPathComponent(UUID().uuidString)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let safe = URL(fileURLWithPath: name).lastPathComponent
        return directory.appendingPathComponent(safe.isEmpty || safe == "." || safe == ".." ? "export" : safe)
    }
    func toggleDiscovery() {
        if scanning { stopDiscovery(); return }
        scanning = true; nearby = []
        discoveryTask = Task {
            for await event in discovery.start() {
                if Task.isCancelled { break }
                switch event {
                case .ready: break
                case .devices(let values): nearby = values
                case .failure(let reason): report("Поиск в сети", reason)
                }
            }
        }
    }
    func stopDiscovery() { discovery.stop(); discoveryTask?.cancel(); discoveryTask = nil; scanning = false }
    func reset() {
        perform("Удаление локальных данных…") {
            await self.disconnect(); self.stopDiscovery()
            try ADBCrypto.deleteStoredIdentity()
            for d in self.devices { try PrivateStore.setToken(nil, for: d.id) }
            try DeviceDisk.save([]); self.devices = []; self.selectedID = nil
            self.files = []; self.packages = []; self.terminal = ""
            let cache = FileManager.default.temporaryDirectory.appendingPathComponent("neonbridge-exports")
            try? FileManager.default.removeItem(at: cache)
        }
    }
}
