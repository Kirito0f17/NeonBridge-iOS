import Foundation
import Security

/// Tokens are never written into the device list or exported logs.
enum PrivateStore {
    static func token(_ id: UUID) -> String? {
        var q = query(id); q[kSecReturnData as String] = true
        var result: CFTypeRef?
        guard SecItemCopyMatching(q as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }
    static func setToken(_ token: String?, for id: UUID) throws {
        let q = query(id)
        guard let token, !token.isEmpty else {
            let deleted = SecItemDelete(q as CFDictionary)
            guard deleted == errSecSuccess || deleted == errSecItemNotFound else { throw BridgeFailure("Не удалось удалить токен из Keychain: \(deleted)") }
            return
        }
        let attributes: [String: Any] = [kSecValueData as String: Data(token.utf8)]
        let status = SecItemUpdate(q as CFDictionary, attributes as CFDictionary)
        if status == errSecItemNotFound {
            var entry = q; entry.merge(attributes) { _, new in new }
            entry[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
            let added = SecItemAdd(entry as CFDictionary, nil)
            guard added == errSecSuccess else { throw BridgeFailure("Не удалось сохранить токен телевизора в Keychain: \(added)") }
        } else if status != errSecSuccess { throw BridgeFailure("Ошибка Keychain: \(status)") }
    }
    private static func query(_ id: UUID) -> [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: "dev.neonbridge.samsung",
         kSecAttrAccount as String: id.uuidString]
    }
}

enum DeviceDisk {
    static func location() throws -> URL {
        var directory = try FileManager.default.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        var values = URLResourceValues(); values.isExcludedFromBackup = true
        try directory.setResourceValues(values)
        return directory.appendingPathComponent("devices.json")
    }
    static func load() throws -> [SavedDevice] {
        let url = try location()
        guard FileManager.default.fileExists(atPath: url.path) else { return [] }
        return try JSONDecoder().decode([SavedDevice].self, from: Data(contentsOf: url))
    }
    static func save(_ devices: [SavedDevice]) throws {
        try JSONEncoder().encode(devices).write(to: location(), options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
    }
}
