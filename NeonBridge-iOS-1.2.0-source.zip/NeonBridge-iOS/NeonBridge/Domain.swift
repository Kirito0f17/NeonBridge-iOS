import Foundation

struct BridgeFailure: LocalizedError {
    let message: String
    var errorDescription: String? { message }
    init(_ message: String) { self.message = message }
}

enum DeviceKind: String, Codable, CaseIterable, Identifiable, Hashable {
    case adb, wireless, samsung, sdb
    var id: String { rawValue }
    var title: String {
        switch self {
        case .adb: return "Android · ADB по IP"
        case .wireless: return "Android 11+ · ADB TLS"
        case .samsung: return "Samsung Tizen · пульт"
        case .sdb: return "Tizen · SDB терминал"
        }
    }
    var defaultPort: String {
        switch self { case .adb: return "5555"; case .wireless: return ""; case .samsung: return "8002"; case .sdb: return "26101" }
    }
    var symbol: String { self == .samsung || self == .sdb ? "tv" : "iphone" }
}
struct SavedDevice: Codable, Identifiable, Hashable {
    var id = UUID()
    var name: String
    var host: String
    var port: UInt16
    var kind: DeviceKind
}
struct ValidatedEndpoint: Equatable {
    let host: String
    let port: UInt16
    init(host: String, port: String) throws {
        var h = host.trimmingCharacters(in: .whitespacesAndNewlines)
        if h.hasPrefix("["), h.hasSuffix("]") { h = String(h.dropFirst().dropLast()) }
        guard !h.isEmpty, h.count <= 253,
              h.unicodeScalars.allSatisfy({ !CharacterSet.whitespacesAndNewlines.contains($0) && !CharacterSet.controlCharacters.contains($0) }),
              !h.contains("/"), !h.contains("?"), !h.contains("#"),
              (!h.contains(":") || h.filter({ $0 == ":" }).count >= 2),
              let p = UInt16(port.trimmingCharacters(in: .whitespacesAndNewlines)), p > 0 else {
            throw BridgeFailure("Укажите IP или имя устройства без http:// и порт от 1 до 65535. Порт вводится отдельно от адреса.")
        }
        let normalized = h.lowercased().trimmingCharacters(in: CharacterSet(charactersIn: "."))
        if normalized == "localhost" || normalized == "localhost.localdomain" || normalized.hasPrefix("127.") || normalized == "::1" || normalized == "0:0:0:0:0:0:0:1" || normalized.hasPrefix("::ffff:127.") {
            throw BridgeFailure("Это локальный адрес самого iPhone. iOS не предоставляет ADB: для управления своим Android-телефоном используйте Android-версию NeonBridge. Здесь укажите IP другого Android или телевизора.")
        }
        self.host = h; self.port = p
    }
}
func bridgeError(_ error: Error) -> String {
    if error is CancellationError { return "Операция отменена." }
    let text = error.localizedDescription
    let lower = text.lowercased()
    let ns = error as NSError
    if lower.contains("refused") || lower.contains("econnrefused") || (ns.domain == NSPOSIXErrorDomain && [61,111].contains(ns.code)) {
        return "Соединение отклонено: выбранный порт не принимает подключение. Проверьте адрес, порт и включение сетевой отладки на устройстве. Режим разработчика сам по себе не включает ADB. Возможен отказ сетевого фильтра.\n\nПриложение не может включить отладку удалённо.\n\n\(text)"
    }
    if lower.contains("timed out") || lower.contains("timeout") || lower.contains("no route") || lower.contains("network is down") {
        return "Устройство не ответило. Проверьте домашнюю сеть, VPN и разрешение «Локальная сеть» для NeonBridge в настройках iPhone. Для Android 11+ порт подключения отличается от порта сопряжения.\n\n\(text)"
    }
    return text
}
