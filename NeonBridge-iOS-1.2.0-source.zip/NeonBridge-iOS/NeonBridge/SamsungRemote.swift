import Foundation
import Security

/// A TV certificate exception is scoped to this session and this explicitly chosen host.
private final class TVTrustDelegate: NSObject, URLSessionDelegate {
    let host: String
    init(host: String) { self.host = host }
    func urlSession(_ session: URLSession, didReceive challenge: URLAuthenticationChallenge,
                    completionHandler: @escaping (URLSession.AuthChallengeDisposition, URLCredential?) -> Void) {
        guard challenge.protectionSpace.host.caseInsensitiveCompare(host) == .orderedSame,
              challenge.protectionSpace.authenticationMethod == NSURLAuthenticationMethodServerTrust,
              let trust = challenge.protectionSpace.serverTrust else {
            completionHandler(.performDefaultHandling, nil); return
        }
        completionHandler(.useCredential, URLCredential(trust: trust))
    }
}

private final class TVPingGate: @unchecked Sendable {
    private let lock = NSLock()
    private var completed = false
    func claim() -> Bool {
        lock.lock(); defer { lock.unlock() }
        guard !completed else { return false }; completed = true; return true
    }
}

@MainActor final class SamsungRemote {
    private var session: URLSession?
    private var socket: URLSessionWebSocketTask?
    private var events: Task<Void, Never>?
    private(set) var connected = false
    var onDisconnect: (() -> Void)?

    func connect(host: String, token: String?) async throws -> String? {
        close()
        var url = URLComponents()
        url.scheme = "wss"; url.host = host; url.port = 8002
        url.path = "/api/v2/channels/samsung.remote.control"
        url.queryItems = [URLQueryItem(name: "name", value: Data("NeonBridge iPhone".utf8).base64EncodedString())]
        if let token, !token.isEmpty { url.queryItems?.append(URLQueryItem(name: "token", value: token)) }
        guard let endpoint = url.url else { throw BridgeFailure("Некорректный адрес телевизора") }
        let config = URLSessionConfiguration.ephemeral
        config.timeoutIntervalForRequest = 35; config.timeoutIntervalForResource = 604800
        let session = URLSession(configuration: config, delegate: TVTrustDelegate(host: host), delegateQueue: nil)
        self.session = session
        let socket = session.webSocketTask(with: endpoint); self.socket = socket; socket.maximumMessageSize = 1_048_576; socket.resume()
        let deadline = Task {
            do { try await Task.sleep(nanoseconds: 30_000_000_000) } catch { return }
            socket.cancel(with: .goingAway, reason: nil)
        }
        defer { deadline.cancel() }
        do {
            let result = try await withTaskCancellationHandler(operation: {
                while true {
                    try Task.checkCancellation()
                    let incoming = try await socket.receive()
                    let event = try Self.json(incoming)
                    switch event["event"] as? String {
                    case "ms.channel.connect":
                        let data = event["data"] as? [String: Any]
                        let value = data?["token"]
                        return (value as? String) ?? (value as? NSNumber)?.stringValue ?? token
                    case "ms.channel.unauthorized", "ms.channel.timeOut", "ms.error":
                        throw BridgeFailure("Телевизор не разрешил подключение. Подтвердите запрос на экране ТВ или разрешите устройство в настройках внешних подключений Samsung.")
                    default: continue
                    }
                }
            }, onCancel: { socket.cancel(with: .goingAway, reason: nil) })
            try Task.checkCancellation(); connected = true
            events = Task { [weak self] in
                do {
                    while !Task.isCancelled {
                        let incoming = try await socket.receive()
                        let event = try Self.json(incoming)
                        if ["ms.channel.unauthorized", "ms.channel.timeOut"].contains(event["event"] as? String ?? "") {
                            throw BridgeFailure("Доступ к пульту отозван")
                        }
                    }
                } catch {
                    guard !Task.isCancelled else { return }
                    self?.connected = false; self?.onDisconnect?()
                }
            }
            return result
        } catch { close(); throw error }
    }
    func verify() async throws {
        guard connected, let socket else { throw BridgeFailure("Пульт отключён") }
        let gate = TVPingGate()
        do {
            _ = try await withTaskCancellationHandler(operation: {
                try Task.checkCancellation()
                return try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Bool, Error>) in
                    let finish: @Sendable (Result<Bool, Error>) -> Void = { result in
                        guard gate.claim() else { return }; continuation.resume(with: result)
                    }
                    socket.sendPing { error in
                        if let error { finish(.failure(error)) } else { finish(.success(true)) }
                    }
                    DispatchQueue.global().asyncAfter(deadline: .now() + 6) {
                        guard gate.claim() else { return }
                        socket.cancel(with: .goingAway, reason: nil)
                        continuation.resume(throwing: BridgeFailure("Телевизор не ответил на ping за 6 секунд (timeout). Подключитесь повторно."))
                    }
                }
            }, onCancel: { socket.cancel(with: .goingAway, reason: nil) })
        } catch { close(); onDisconnect?(); throw error }
    }
    func key(_ key: String) async throws {
        guard connected, let socket else { throw BridgeFailure("Пульт отключён") }
        let request: [String: Any] = ["method": "ms.remote.control", "params": [
            "Cmd": "Click", "DataOfCmd": key, "Option": "false", "TypeOfRemote": "SendRemoteKey"]]
        let data = try JSONSerialization.data(withJSONObject: request)
        do { try await socket.send(.string(String(decoding: data, as: UTF8.self))) }
        catch { close(); onDisconnect?(); throw error }
    }
    func close() {
        connected = false; events?.cancel(); events = nil
        socket?.cancel(with: .normalClosure, reason: nil); socket = nil
        session?.invalidateAndCancel(); session = nil
    }
    private static func json(_ message: URLSessionWebSocketTask.Message) throws -> [String: Any] {
        let data: Data
        switch message { case .string(let s): data = Data(s.utf8); case .data(let d): data = d; @unknown default: throw BridgeFailure("Неизвестный ответ пульта") }
        guard data.count <= 1_048_576,
              let result = try JSONSerialization.jsonObject(with: data) as? [String: Any] else { throw BridgeFailure("Некорректный ответ телевизора") }
        return result
    }
}
