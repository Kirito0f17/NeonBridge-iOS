import SwiftUI

@main @MainActor struct NeonBridgeApp: App {
    @StateObject private var model = BridgeModel()
    var body: some Scene {
        WindowGroup { RootView().environmentObject(model).preferredColorScheme(.dark) }
    }
}

extension Color {
    static let bridgeBackground = Color(red: 0.03, green: 0.05, blue: 0.09)
    static let bridgePanel = Color(red: 0.06, green: 0.10, blue: 0.17)
    static let bridgeCyan = Color(red: 0, green: 0.87, blue: 0.93)
}
struct Panel<Content: View>: View {
    @ViewBuilder var content: () -> Content
    var body: some View {
        VStack(alignment: .leading, spacing: 12, content: content)
            .frame(maxWidth: .infinity, alignment: .leading).padding(18)
            .background(Color.bridgePanel, in: RoundedRectangle(cornerRadius: 18))
            .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.bridgeCyan.opacity(0.20)))
    }
}
struct SectionLabel: View {
    let title: String
    var body: some View { Text("// " + title).font(.system(.caption, design: .monospaced)).foregroundStyle(.secondary).padding(.top, 16) }
}
struct GridBackdrop: View {
    var body: some View {
        Canvas { context, size in
            var grid = Path()
            for x in stride(from: 0.0, through: size.width, by: 42) { grid.move(to: CGPoint(x: x, y: 0)); grid.addLine(to: CGPoint(x: x, y: size.height)) }
            for y in stride(from: 0.0, through: size.height, by: 42) { grid.move(to: CGPoint(x: 0, y: y)); grid.addLine(to: CGPoint(x: size.width, y: y)) }
            context.stroke(grid, with: .color(.white.opacity(0.035)), lineWidth: 1)
        }.background(Color.bridgeBackground).ignoresSafeArea().allowsHitTesting(false)
    }
}
struct Screen<Content: View>: View {
    let title: String
    @ViewBuilder var content: () -> Content
    var body: some View {
        ZStack {
            GridBackdrop()
            ScrollView { VStack(alignment: .leading, spacing: 16, content: content).padding(18).frame(maxWidth: 760) }
        }.navigationTitle(title).navigationBarTitleDisplayMode(.inline)
    }
}
struct ActiveDeviceBar: View {
    @EnvironmentObject var model: BridgeModel
    var body: some View {
        Panel {
            HStack {
                Circle().fill(model.connected ? .green : .gray).frame(width: 8, height: 8)
                Text(model.selected?.name ?? "Устройство не выбрано").lineLimit(1)
                Spacer()
                Text(model.connected ? "ONLINE" : "OFFLINE").foregroundStyle(model.connected ? Color.green : Color.secondary)
            }.font(.system(.caption, design: .monospaced))
            if let d = model.selected { Text("\(d.host):\(d.port)").font(.caption).foregroundStyle(Color.bridgeCyan) }
        }
    }
}
