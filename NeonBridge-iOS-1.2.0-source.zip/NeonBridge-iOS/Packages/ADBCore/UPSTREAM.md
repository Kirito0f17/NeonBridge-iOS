# ADBCore origin

Source: https://github.com/h33h/iadb-ios
Revision: 22902f6231c413f2d90accee68f0e59f1c9ea360
License: MIT, Copyright (c) 2026 h33h. Full license is in LICENSE and app resources.

Only the package Sources/ADBCore and Tests/ADBCoreTests are included.
The upstream app UI is not included.

Local changes:
- Package manifest uses Swift tools 6.0, Swift language mode 5 instead of upstream tools 6.4, to support hosted Xcode 16+ toolchains. Compatibility must be confirmed by the included macOS CI.
- Keychain RSA tag and logging subsystem use NeonBridge identifiers. Generated private keys use AfterFirstUnlockThisDeviceOnly accessibility.
- ADBClient.connect adds optional legacySDB flag; it sends CNXN version 0x00100000 for Tizen SDB. The default ADB handshake is unchanged. SDB is used only for raw shell in this app.
- ADBClient.connect adds optional requireTLS (default false). Wireless ADB callers require STLS and reject an initial plaintext CNXN or AUTH before sending an authentication signature or public key. Legacy SDB cannot require ADB TLS. Scripted transport tests cover both plaintext rejection paths, the required STLS upgrade, and conflicting SDB/TLS options. TLS certificate pinning remains an upstream limitation.

Upstream tests are retained. Their presence does not mean they were run in this Linux workspace.
