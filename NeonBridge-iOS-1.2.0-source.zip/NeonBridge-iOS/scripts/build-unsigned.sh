#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ "$(uname -s)" != "Darwin" ]]; then
  echo 'iOS SDK requires macOS. On Windows run the included GitHub Actions workflow.' >&2
  exit 1
fi
if ! command -v xcodegen >/dev/null; then
  echo 'Install XcodeGen: brew install xcodegen' >&2
  exit 1
fi
xcodegen generate
xcodebuild -project NeonBridge.xcodeproj -scheme NeonBridge -configuration Release \
  -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath build \
  CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO build
app_path=build/Build/Products/Release-iphoneos/NeonBridge.app
[[ -d "$app_path" ]]
mkdir -p dist
rm -rf dist/Payload
mkdir -p dist/Payload
cp -R "$app_path" dist/Payload/NeonBridge.app
(cd dist && /usr/bin/zip -q -r NeonBridge-unsigned.ipa Payload)
/usr/bin/unzip -t dist/NeonBridge-unsigned.ipa
printf '\nUnsigned IPA: dist/NeonBridge-unsigned.ipa\nThis file requires re-signing before installing on an iPhone.\n'
