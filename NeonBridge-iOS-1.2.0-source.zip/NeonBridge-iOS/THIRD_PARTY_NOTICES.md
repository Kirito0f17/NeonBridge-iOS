# Открытые компоненты

В проект включён пакет ADBCore из https://github.com/h33h/iadb-ios,
commit `22902f6231c413f2d90accee68f0e59f1c9ea360`.
Copyright (c) 2026 h33h, MIT License.

Полная лицензия: `Packages/ADBCore/LICENSE` и `NeonBridge/ADBCore-LICENSE.txt`.
Локальные изменения: `Packages/ADBCore/UPSTREAM.md`.

Интерфейс NeonBridge и адаптер Samsung не взяты из UI исходного проекта.
Внешних Swift Package-загрузок при сборке нет. Пакет использует штатные Apple
Foundation, Network, Security, CryptoKit и os, тесты — Swift Testing.

Java/Android, SPAKE2-android и Conscrypt из Android-версии в iPhone-проект не включены.
